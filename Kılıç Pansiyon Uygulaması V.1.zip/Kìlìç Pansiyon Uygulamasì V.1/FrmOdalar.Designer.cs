﻿namespace Kılıç_Pansiyon_Uygulaması_V._1
{
    partial class FrmOdalar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnOda109 = new Button();
            BtnOda108 = new Button();
            BtnOda107 = new Button();
            BtnOda106 = new Button();
            BtnOda105 = new Button();
            BtnOda104 = new Button();
            BtnOda103 = new Button();
            BtnOda102 = new Button();
            BtnOda101 = new Button();
            SuspendLayout();
            // 
            // BtnOda109
            // 
            BtnOda109.BackColor = Color.GreenYellow;
            BtnOda109.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda109.Location = new Point(585, 400);
            BtnOda109.Name = "BtnOda109";
            BtnOda109.Size = new Size(129, 158);
            BtnOda109.TabIndex = 17;
            BtnOda109.Text = "109";
            BtnOda109.UseVisualStyleBackColor = false;
            // 
            // BtnOda108
            // 
            BtnOda108.BackColor = Color.GreenYellow;
            BtnOda108.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda108.Location = new Point(346, 400);
            BtnOda108.Name = "BtnOda108";
            BtnOda108.Size = new Size(129, 158);
            BtnOda108.TabIndex = 16;
            BtnOda108.Text = "108";
            BtnOda108.UseVisualStyleBackColor = false;
            // 
            // BtnOda107
            // 
            BtnOda107.BackColor = Color.GreenYellow;
            BtnOda107.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda107.Location = new Point(100, 400);
            BtnOda107.Name = "BtnOda107";
            BtnOda107.Size = new Size(129, 158);
            BtnOda107.TabIndex = 15;
            BtnOda107.Text = "107";
            BtnOda107.UseVisualStyleBackColor = false;
            // 
            // BtnOda106
            // 
            BtnOda106.BackColor = Color.GreenYellow;
            BtnOda106.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda106.Location = new Point(585, 207);
            BtnOda106.Name = "BtnOda106";
            BtnOda106.Size = new Size(129, 158);
            BtnOda106.TabIndex = 14;
            BtnOda106.Text = "106";
            BtnOda106.UseVisualStyleBackColor = false;
            // 
            // BtnOda105
            // 
            BtnOda105.BackColor = Color.GreenYellow;
            BtnOda105.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda105.Location = new Point(346, 207);
            BtnOda105.Name = "BtnOda105";
            BtnOda105.Size = new Size(129, 158);
            BtnOda105.TabIndex = 13;
            BtnOda105.Text = "105";
            BtnOda105.UseVisualStyleBackColor = false;
            // 
            // BtnOda104
            // 
            BtnOda104.BackColor = Color.GreenYellow;
            BtnOda104.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda104.Location = new Point(100, 207);
            BtnOda104.Name = "BtnOda104";
            BtnOda104.Size = new Size(129, 158);
            BtnOda104.TabIndex = 12;
            BtnOda104.Text = "104";
            BtnOda104.UseVisualStyleBackColor = false;
            // 
            // BtnOda103
            // 
            BtnOda103.BackColor = Color.GreenYellow;
            BtnOda103.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda103.Location = new Point(585, 21);
            BtnOda103.Name = "BtnOda103";
            BtnOda103.Size = new Size(129, 158);
            BtnOda103.TabIndex = 11;
            BtnOda103.Text = "103";
            BtnOda103.UseVisualStyleBackColor = false;
            // 
            // BtnOda102
            // 
            BtnOda102.BackColor = Color.GreenYellow;
            BtnOda102.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda102.Location = new Point(346, 21);
            BtnOda102.Name = "BtnOda102";
            BtnOda102.Size = new Size(129, 158);
            BtnOda102.TabIndex = 10;
            BtnOda102.Text = "102";
            BtnOda102.UseVisualStyleBackColor = false;
            // 
            // BtnOda101
            // 
            BtnOda101.BackColor = Color.GreenYellow;
            BtnOda101.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda101.Location = new Point(100, 21);
            BtnOda101.Name = "BtnOda101";
            BtnOda101.Size = new Size(129, 158);
            BtnOda101.TabIndex = 9;
            BtnOda101.Text = "101";
            BtnOda101.UseVisualStyleBackColor = false;
            // 
            // FrmOdalar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(814, 578);
            Controls.Add(BtnOda109);
            Controls.Add(BtnOda108);
            Controls.Add(BtnOda107);
            Controls.Add(BtnOda106);
            Controls.Add(BtnOda105);
            Controls.Add(BtnOda104);
            Controls.Add(BtnOda103);
            Controls.Add(BtnOda102);
            Controls.Add(BtnOda101);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmOdalar";
            Text = "Odalar";
            Load += FrmOdalar_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button BtnOda109;
        private Button BtnOda108;
        private Button BtnOda107;
        private Button BtnOda106;
        private Button BtnOda105;
        private Button BtnOda104;
        private Button BtnOda103;
        private Button BtnOda102;
        private Button BtnOda101;
    }
}