﻿namespace Kılıç_Pansiyon_Uygulaması_V._1
{
    partial class FrmYeniMusteri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label16 = new Label();
            comboBox1 = new ComboBox();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            TxtUcret = new TextBox();
            label9 = new Label();
            TxtOdaNo = new TextBox();
            label8 = new Label();
            BtnKaydet = new Button();
            DtpCikisTarihi = new DateTimePicker();
            DtpGirisTarihi = new DateTimePicker();
            MskTxtTelefon = new MaskedTextBox();
            TxtKimlikNo = new TextBox();
            TxtMail = new TextBox();
            TxtSoyadi = new TextBox();
            TxtAdi = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            BtnOda109 = new Button();
            BtnOda108 = new Button();
            BtnOda107 = new Button();
            BtnOda106 = new Button();
            BtnOda105 = new Button();
            BtnOda104 = new Button();
            BtnOda103 = new Button();
            BtnOda102 = new Button();
            BtnOda101 = new Button();
            BtnBosOda = new Button();
            BtnDoluOda = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(TxtUcret);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(TxtOdaNo);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(BtnKaydet);
            groupBox1.Controls.Add(DtpCikisTarihi);
            groupBox1.Controls.Add(DtpGirisTarihi);
            groupBox1.Controls.Add(MskTxtTelefon);
            groupBox1.Controls.Add(TxtKimlikNo);
            groupBox1.Controls.Add(TxtMail);
            groupBox1.Controls.Add(TxtSoyadi);
            groupBox1.Controls.Add(TxtAdi);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(78, 61);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(442, 598);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Müşteri Bilgileri";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(380, 550);
            label16.Name = "label16";
            label16.Size = new Size(17, 20);
            label16.TabIndex = 44;
            label16.Text = "0";
            label16.Visible = false;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.FromArgb(255, 255, 192);
            comboBox1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Erkek", "Kadın" });
            comboBox1.Location = new Point(162, 154);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(250, 36);
            comboBox1.TabIndex = 43;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label15.Location = new Point(6, 153);
            label15.Name = "label15";
            label15.Size = new Size(82, 25);
            label15.TabIndex = 42;
            label15.Text = "Cinsiyet:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label14.Location = new Point(6, 443);
            label14.Name = "label14";
            label14.Size = new Size(103, 25);
            label14.TabIndex = 41;
            label14.Text = "Giriş Tarihi:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(6, 390);
            label13.Name = "label13";
            label13.Size = new Size(61, 25);
            label13.TabIndex = 40;
            label13.Text = "Ücret:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(0, 291);
            label12.Name = "label12";
            label12.Size = new Size(129, 25);
            label12.TabIndex = 39;
            label12.Text = "T.C. Kimlik No:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label11.Location = new Point(6, 248);
            label11.Name = "label11";
            label11.Size = new Size(68, 25);
            label11.TabIndex = 38;
            label11.Text = "E-Mail:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(6, 64);
            label10.Name = "label10";
            label10.Size = new Size(44, 25);
            label10.TabIndex = 37;
            label10.Text = "Adı:";
            // 
            // TxtUcret
            // 
            TxtUcret.BackColor = Color.FromArgb(255, 255, 192);
            TxtUcret.Enabled = false;
            TxtUcret.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtUcret.Location = new Point(162, 383);
            TxtUcret.Name = "TxtUcret";
            TxtUcret.Size = new Size(250, 34);
            TxtUcret.TabIndex = 36;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(688, 341);
            label9.Name = "label9";
            label9.Size = new Size(61, 25);
            label9.TabIndex = 35;
            label9.Text = "Ücret:";
            // 
            // TxtOdaNo
            // 
            TxtOdaNo.BackColor = Color.FromArgb(255, 255, 192);
            TxtOdaNo.Enabled = false;
            TxtOdaNo.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtOdaNo.Location = new Point(162, 335);
            TxtOdaNo.Name = "TxtOdaNo";
            TxtOdaNo.Size = new Size(250, 34);
            TxtOdaNo.TabIndex = 34;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(1, 341);
            label8.Name = "label8";
            label8.Size = new Size(134, 25);
            label8.TabIndex = 33;
            label8.Text = "Oda Numarası:";
            // 
            // BtnKaydet
            // 
            BtnKaydet.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            BtnKaydet.Location = new Point(29, 550);
            BtnKaydet.Name = "BtnKaydet";
            BtnKaydet.Size = new Size(177, 40);
            BtnKaydet.TabIndex = 32;
            BtnKaydet.Text = "Kaydet";
            BtnKaydet.UseVisualStyleBackColor = true;
            BtnKaydet.Click += BtnKaydet_Click;
            // 
            // DtpCikisTarihi
            // 
            DtpCikisTarihi.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            DtpCikisTarihi.Location = new Point(162, 483);
            DtpCikisTarihi.Name = "DtpCikisTarihi";
            DtpCikisTarihi.Size = new Size(250, 31);
            DtpCikisTarihi.TabIndex = 31;
            DtpCikisTarihi.ValueChanged += DtpCikisTarihi_ValueChanged;
            // 
            // DtpGirisTarihi
            // 
            DtpGirisTarihi.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            DtpGirisTarihi.Location = new Point(162, 435);
            DtpGirisTarihi.Name = "DtpGirisTarihi";
            DtpGirisTarihi.Size = new Size(250, 31);
            DtpGirisTarihi.TabIndex = 30;
            // 
            // MskTxtTelefon
            // 
            MskTxtTelefon.BackColor = Color.FromArgb(255, 255, 192);
            MskTxtTelefon.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            MskTxtTelefon.Location = new Point(162, 200);
            MskTxtTelefon.Mask = "(999) 000-0000";
            MskTxtTelefon.Name = "MskTxtTelefon";
            MskTxtTelefon.Size = new Size(250, 34);
            MskTxtTelefon.TabIndex = 29;
            // 
            // TxtKimlikNo
            // 
            TxtKimlikNo.BackColor = Color.FromArgb(255, 255, 192);
            TxtKimlikNo.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtKimlikNo.Location = new Point(162, 285);
            TxtKimlikNo.MaxLength = 11;
            TxtKimlikNo.Name = "TxtKimlikNo";
            TxtKimlikNo.Size = new Size(250, 34);
            TxtKimlikNo.TabIndex = 28;
            // 
            // TxtMail
            // 
            TxtMail.BackColor = Color.FromArgb(255, 255, 192);
            TxtMail.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtMail.Location = new Point(162, 242);
            TxtMail.Name = "TxtMail";
            TxtMail.Size = new Size(250, 34);
            TxtMail.TabIndex = 27;
            // 
            // TxtSoyadi
            // 
            TxtSoyadi.BackColor = Color.FromArgb(255, 255, 192);
            TxtSoyadi.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtSoyadi.Location = new Point(162, 104);
            TxtSoyadi.Name = "TxtSoyadi";
            TxtSoyadi.Size = new Size(250, 34);
            TxtSoyadi.TabIndex = 26;
            // 
            // TxtAdi
            // 
            TxtAdi.BackColor = Color.FromArgb(255, 255, 192);
            TxtAdi.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtAdi.Location = new Point(162, 58);
            TxtAdi.Name = "TxtAdi";
            TxtAdi.Size = new Size(250, 34);
            TxtAdi.TabIndex = 25;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(6, 489);
            label7.Name = "label7";
            label7.Size = new Size(99, 25);
            label7.TabIndex = 24;
            label7.Text = "Çıkış Tarihi";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(285, 443);
            label6.Name = "label6";
            label6.Size = new Size(92, 23);
            label6.TabIndex = 23;
            label6.Text = "Giriş Tarihi:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(569, 241);
            label5.Name = "label5";
            label5.Size = new Size(119, 23);
            label5.TabIndex = 22;
            label5.Text = "T.C. Kimlik No:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(506, 198);
            label4.Name = "label4";
            label4.Size = new Size(63, 23);
            label4.TabIndex = 21;
            label4.Text = "E-Mail:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(6, 203);
            label3.Name = "label3";
            label3.Size = new Size(77, 25);
            label3.TabIndex = 20;
            label3.Text = "Telefon:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(6, 110);
            label2.Name = "label2";
            label2.Size = new Size(71, 25);
            label2.TabIndex = 19;
            label2.Text = "Soyadı:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(467, 66);
            label1.Name = "label1";
            label1.Size = new Size(39, 23);
            label1.TabIndex = 18;
            label1.Text = "Adı:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(BtnOda109);
            groupBox2.Controls.Add(BtnOda108);
            groupBox2.Controls.Add(BtnOda107);
            groupBox2.Controls.Add(BtnOda106);
            groupBox2.Controls.Add(BtnOda105);
            groupBox2.Controls.Add(BtnOda104);
            groupBox2.Controls.Add(BtnOda103);
            groupBox2.Controls.Add(BtnOda102);
            groupBox2.Controls.Add(BtnOda101);
            groupBox2.Location = new Point(624, 61);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(374, 525);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Odalar";
            // 
            // BtnOda109
            // 
            BtnOda109.BackColor = Color.GreenYellow;
            BtnOda109.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda109.Location = new Point(260, 375);
            BtnOda109.Name = "BtnOda109";
            BtnOda109.Size = new Size(94, 57);
            BtnOda109.TabIndex = 8;
            BtnOda109.Text = "109";
            BtnOda109.UseVisualStyleBackColor = false;
            BtnOda109.Click += BtnOda109_Click;
            // 
            // BtnOda108
            // 
            BtnOda108.BackColor = Color.GreenYellow;
            BtnOda108.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda108.Location = new Point(137, 375);
            BtnOda108.Name = "BtnOda108";
            BtnOda108.Size = new Size(94, 57);
            BtnOda108.TabIndex = 7;
            BtnOda108.Text = "108";
            BtnOda108.UseVisualStyleBackColor = false;
            BtnOda108.Click += BtnOda108_Click;
            // 
            // BtnOda107
            // 
            BtnOda107.BackColor = Color.GreenYellow;
            BtnOda107.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda107.Location = new Point(18, 375);
            BtnOda107.Name = "BtnOda107";
            BtnOda107.Size = new Size(94, 57);
            BtnOda107.TabIndex = 6;
            BtnOda107.Text = "107";
            BtnOda107.UseVisualStyleBackColor = false;
            BtnOda107.Click += BtnOda107_Click;
            // 
            // BtnOda106
            // 
            BtnOda106.BackColor = Color.GreenYellow;
            BtnOda106.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda106.Location = new Point(260, 223);
            BtnOda106.Name = "BtnOda106";
            BtnOda106.Size = new Size(94, 57);
            BtnOda106.TabIndex = 5;
            BtnOda106.Text = "106";
            BtnOda106.UseVisualStyleBackColor = false;
            BtnOda106.Click += BtnOda106_Click;
            // 
            // BtnOda105
            // 
            BtnOda105.BackColor = Color.GreenYellow;
            BtnOda105.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda105.Location = new Point(137, 223);
            BtnOda105.Name = "BtnOda105";
            BtnOda105.Size = new Size(94, 57);
            BtnOda105.TabIndex = 4;
            BtnOda105.Text = "105";
            BtnOda105.UseVisualStyleBackColor = false;
            BtnOda105.Click += BtnOda105_Click;
            // 
            // BtnOda104
            // 
            BtnOda104.BackColor = Color.GreenYellow;
            BtnOda104.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda104.Location = new Point(18, 223);
            BtnOda104.Name = "BtnOda104";
            BtnOda104.Size = new Size(94, 57);
            BtnOda104.TabIndex = 3;
            BtnOda104.Text = "104";
            BtnOda104.UseVisualStyleBackColor = false;
            BtnOda104.Click += BtnOda104_Click;
            // 
            // BtnOda103
            // 
            BtnOda103.BackColor = Color.GreenYellow;
            BtnOda103.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda103.Location = new Point(260, 76);
            BtnOda103.Name = "BtnOda103";
            BtnOda103.Size = new Size(94, 57);
            BtnOda103.TabIndex = 2;
            BtnOda103.Text = "103";
            BtnOda103.UseVisualStyleBackColor = false;
            BtnOda103.Click += BtnOda103_Click;
            // 
            // BtnOda102
            // 
            BtnOda102.BackColor = Color.GreenYellow;
            BtnOda102.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda102.Location = new Point(137, 76);
            BtnOda102.Name = "BtnOda102";
            BtnOda102.Size = new Size(94, 57);
            BtnOda102.TabIndex = 1;
            BtnOda102.Text = "102";
            BtnOda102.UseVisualStyleBackColor = false;
            BtnOda102.Click += BtnOda102_Click;
            // 
            // BtnOda101
            // 
            BtnOda101.BackColor = Color.GreenYellow;
            BtnOda101.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOda101.Location = new Point(18, 78);
            BtnOda101.Name = "BtnOda101";
            BtnOda101.Size = new Size(94, 57);
            BtnOda101.TabIndex = 0;
            BtnOda101.Text = "101";
            BtnOda101.UseVisualStyleBackColor = false;
            BtnOda101.Click += BtnOda101_Click;
            // 
            // BtnBosOda
            // 
            BtnBosOda.BackColor = Color.GreenYellow;
            BtnBosOda.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnBosOda.Location = new Point(701, 611);
            BtnBosOda.Name = "BtnBosOda";
            BtnBosOda.Size = new Size(94, 57);
            BtnBosOda.TabIndex = 9;
            BtnBosOda.Text = "Boş";
            BtnBosOda.UseVisualStyleBackColor = false;
            BtnBosOda.Click += BtnBosOda_Click;
            // 
            // BtnDoluOda
            // 
            BtnDoluOda.BackColor = Color.Red;
            BtnDoluOda.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            BtnDoluOda.Location = new Point(870, 611);
            BtnDoluOda.Name = "BtnDoluOda";
            BtnDoluOda.Size = new Size(94, 57);
            BtnDoluOda.TabIndex = 10;
            BtnDoluOda.Text = "Dolu";
            BtnDoluOda.UseVisualStyleBackColor = false;
            BtnDoluOda.Click += BtnDoluOda_Click;
            // 
            // FrmYeniMusteri
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.Cyan;
            ClientSize = new Size(1046, 680);
            Controls.Add(BtnDoluOda);
            Controls.Add(groupBox2);
            Controls.Add(BtnBosOda);
            Controls.Add(groupBox1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmYeniMusteri";
            Text = "Yeni Müşteri Ekle ";
            Load += FrmYeniMusteri_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button BtnKaydet;
        private DateTimePicker DtpCikisTarihi;
        private DateTimePicker DtpGirisTarihi;
        private MaskedTextBox MskTxtTelefon;
        private TextBox TxtKimlikNo;
        private TextBox TxtMail;
        private TextBox TxtSoyadi;
        private TextBox TxtAdi;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private GroupBox groupBox2;
        private Button BtnOda103;
        private Button BtnOda102;
        private Button BtnOda101;
        private Button BtnOda109;
        private Button BtnOda108;
        private Button BtnOda107;
        private Button BtnOda106;
        private Button BtnOda105;
        private Button BtnOda104;
        private Button BtnBosOda;
        private Button BtnDoluOda;
        private TextBox TxtOdaNo;
        private Label label8;
        private TextBox TxtUcret;
        private Label label9;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private ComboBox comboBox1;
        private Label label15;
        private Label label16;
    }
}