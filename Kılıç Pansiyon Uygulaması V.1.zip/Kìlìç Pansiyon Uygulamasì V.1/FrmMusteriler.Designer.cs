﻿namespace Kılıç_Pansiyon_Uygulaması_V._1
{
    partial class FrmMusteriler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            columnHeader6 = new ColumnHeader();
            columnHeader7 = new ColumnHeader();
            columnHeader8 = new ColumnHeader();
            columnHeader9 = new ColumnHeader();
            columnHeader10 = new ColumnHeader();
            columnHeader11 = new ColumnHeader();
            BtnVerileriGoster = new Button();
            BtnGuncelle = new Button();
            BtnSil = new Button();
            BtnAra = new Button();
            comboBox1 = new ComboBox();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            TxtUcret = new TextBox();
            TxtOdaNo = new TextBox();
            label8 = new Label();
            DtpCikisTarihi = new DateTimePicker();
            DtpGirisTarihi = new DateTimePicker();
            MskTxtTelefon = new MaskedTextBox();
            TxtKimlikNo = new TextBox();
            TxtMail = new TextBox();
            TxtSoyadi = new TextBox();
            TxtAdi = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox1 = new TextBox();
            BtnTemizle = new Button();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4, columnHeader5, columnHeader6, columnHeader7, columnHeader8, columnHeader9, columnHeader10, columnHeader11 });
            listView1.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            listView1.Location = new Point(4, 532);
            listView1.Name = "listView1";
            listView1.Size = new Size(1137, 242);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "No";
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Adı";
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Soyadı";
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Cinsiyet";
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "Telefon";
            // 
            // columnHeader6
            // 
            columnHeader6.Text = "Mail";
            // 
            // columnHeader7
            // 
            columnHeader7.Text = "TC";
            // 
            // columnHeader8
            // 
            columnHeader8.Text = "OdaNo";
            // 
            // columnHeader9
            // 
            columnHeader9.Text = "Ücret";
            // 
            // columnHeader10
            // 
            columnHeader10.Text = "G.Tarihi";
            // 
            // columnHeader11
            // 
            columnHeader11.Text = "Ç.Tarihi";
            // 
            // BtnVerileriGoster
            // 
            BtnVerileriGoster.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            BtnVerileriGoster.Location = new Point(610, 4);
            BtnVerileriGoster.Name = "BtnVerileriGoster";
            BtnVerileriGoster.Size = new Size(220, 51);
            BtnVerileriGoster.TabIndex = 1;
            BtnVerileriGoster.Text = "Verileri Göster";
            BtnVerileriGoster.UseVisualStyleBackColor = true;
            BtnVerileriGoster.Click += button1_Click;
            // 
            // BtnGuncelle
            // 
            BtnGuncelle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            BtnGuncelle.Location = new Point(610, 80);
            BtnGuncelle.Name = "BtnGuncelle";
            BtnGuncelle.Size = new Size(220, 52);
            BtnGuncelle.TabIndex = 2;
            BtnGuncelle.Text = "Güncelle";
            BtnGuncelle.UseVisualStyleBackColor = true;
            BtnGuncelle.Click += BtnGuncelle_Click;
            // 
            // BtnSil
            // 
            BtnSil.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSil.Location = new Point(610, 157);
            BtnSil.Name = "BtnSil";
            BtnSil.Size = new Size(220, 57);
            BtnSil.TabIndex = 3;
            BtnSil.Text = "Sil";
            BtnSil.UseVisualStyleBackColor = true;
            BtnSil.Click += BtnSil_Click;
            // 
            // BtnAra
            // 
            BtnAra.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            BtnAra.Location = new Point(610, 344);
            BtnAra.Name = "BtnAra";
            BtnAra.Size = new Size(220, 53);
            BtnAra.TabIndex = 4;
            BtnAra.Text = "Ara";
            BtnAra.UseVisualStyleBackColor = true;
            BtnAra.Click += BtnAra_Click;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.FromArgb(255, 255, 192);
            comboBox1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Erkek", "Kadın" });
            comboBox1.Location = new Point(191, 108);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(250, 36);
            comboBox1.TabIndex = 64;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label15.Location = new Point(35, 107);
            label15.Name = "label15";
            label15.Size = new Size(82, 25);
            label15.TabIndex = 63;
            label15.Text = "Cinsiyet:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label14.Location = new Point(35, 397);
            label14.Name = "label14";
            label14.Size = new Size(103, 25);
            label14.TabIndex = 62;
            label14.Text = "Giriş Tarihi:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(35, 344);
            label13.Name = "label13";
            label13.Size = new Size(61, 25);
            label13.TabIndex = 61;
            label13.Text = "Ücret:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(29, 245);
            label12.Name = "label12";
            label12.Size = new Size(129, 25);
            label12.TabIndex = 60;
            label12.Text = "T.C. Kimlik No:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label11.Location = new Point(35, 202);
            label11.Name = "label11";
            label11.Size = new Size(68, 25);
            label11.TabIndex = 59;
            label11.Text = "E-Mail:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(35, 18);
            label10.Name = "label10";
            label10.Size = new Size(44, 25);
            label10.TabIndex = 58;
            label10.Text = "Adı:";
            // 
            // TxtUcret
            // 
            TxtUcret.BackColor = Color.FromArgb(255, 255, 192);
            TxtUcret.Enabled = false;
            TxtUcret.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtUcret.Location = new Point(191, 337);
            TxtUcret.Name = "TxtUcret";
            TxtUcret.Size = new Size(250, 34);
            TxtUcret.TabIndex = 57;
            // 
            // TxtOdaNo
            // 
            TxtOdaNo.BackColor = Color.FromArgb(255, 255, 192);
            TxtOdaNo.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtOdaNo.Location = new Point(191, 289);
            TxtOdaNo.Name = "TxtOdaNo";
            TxtOdaNo.Size = new Size(250, 34);
            TxtOdaNo.TabIndex = 56;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(30, 295);
            label8.Name = "label8";
            label8.Size = new Size(134, 25);
            label8.TabIndex = 55;
            label8.Text = "Oda Numarası:";
            // 
            // DtpCikisTarihi
            // 
            DtpCikisTarihi.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            DtpCikisTarihi.Location = new Point(191, 437);
            DtpCikisTarihi.Name = "DtpCikisTarihi";
            DtpCikisTarihi.Size = new Size(250, 31);
            DtpCikisTarihi.TabIndex = 54;
            // 
            // DtpGirisTarihi
            // 
            DtpGirisTarihi.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            DtpGirisTarihi.Location = new Point(191, 389);
            DtpGirisTarihi.Name = "DtpGirisTarihi";
            DtpGirisTarihi.Size = new Size(250, 31);
            DtpGirisTarihi.TabIndex = 53;
            // 
            // MskTxtTelefon
            // 
            MskTxtTelefon.BackColor = Color.FromArgb(255, 255, 192);
            MskTxtTelefon.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            MskTxtTelefon.Location = new Point(191, 154);
            MskTxtTelefon.Mask = "(999) 000-0000";
            MskTxtTelefon.Name = "MskTxtTelefon";
            MskTxtTelefon.Size = new Size(250, 34);
            MskTxtTelefon.TabIndex = 52;
            // 
            // TxtKimlikNo
            // 
            TxtKimlikNo.BackColor = Color.FromArgb(255, 255, 192);
            TxtKimlikNo.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtKimlikNo.Location = new Point(191, 239);
            TxtKimlikNo.MaxLength = 11;
            TxtKimlikNo.Name = "TxtKimlikNo";
            TxtKimlikNo.Size = new Size(250, 34);
            TxtKimlikNo.TabIndex = 51;
            // 
            // TxtMail
            // 
            TxtMail.BackColor = Color.FromArgb(255, 255, 192);
            TxtMail.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtMail.Location = new Point(191, 196);
            TxtMail.Name = "TxtMail";
            TxtMail.Size = new Size(250, 34);
            TxtMail.TabIndex = 50;
            // 
            // TxtSoyadi
            // 
            TxtSoyadi.BackColor = Color.FromArgb(255, 255, 192);
            TxtSoyadi.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtSoyadi.Location = new Point(191, 58);
            TxtSoyadi.Name = "TxtSoyadi";
            TxtSoyadi.Size = new Size(250, 34);
            TxtSoyadi.TabIndex = 49;
            // 
            // TxtAdi
            // 
            TxtAdi.BackColor = Color.FromArgb(255, 255, 192);
            TxtAdi.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TxtAdi.Location = new Point(191, 12);
            TxtAdi.Name = "TxtAdi";
            TxtAdi.Size = new Size(250, 34);
            TxtAdi.TabIndex = 48;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(35, 443);
            label7.Name = "label7";
            label7.Size = new Size(99, 25);
            label7.TabIndex = 47;
            label7.Text = "Çıkış Tarihi";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(314, 397);
            label6.Name = "label6";
            label6.Size = new Size(92, 23);
            label6.TabIndex = 46;
            label6.Text = "Giriş Tarihi:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(35, 157);
            label3.Name = "label3";
            label3.Size = new Size(77, 25);
            label3.TabIndex = 45;
            label3.Text = "Telefon:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(35, 64);
            label2.Name = "label2";
            label2.Size = new Size(71, 25);
            label2.TabIndex = 44;
            label2.Text = "Soyadı:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(482, 455);
            label1.Name = "label1";
            label1.Size = new Size(83, 25);
            label1.TabIndex = 66;
            label1.Text = "İsim Ara:";
            label1.Click += label1_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(255, 255, 192);
            textBox1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            textBox1.Location = new Point(592, 446);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(250, 34);
            textBox1.TabIndex = 65;
            // 
            // BtnTemizle
            // 
            BtnTemizle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            BtnTemizle.Location = new Point(610, 245);
            BtnTemizle.Name = "BtnTemizle";
            BtnTemizle.Size = new Size(220, 55);
            BtnTemizle.TabIndex = 67;
            BtnTemizle.Text = "Temizle";
            BtnTemizle.UseVisualStyleBackColor = true;
            BtnTemizle.Click += BtnTemizle_Click;
            // 
            // FrmMusteriler
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(128, 255, 128);
            ClientSize = new Size(1153, 786);
            Controls.Add(BtnTemizle);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Controls.Add(comboBox1);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(TxtUcret);
            Controls.Add(TxtOdaNo);
            Controls.Add(label8);
            Controls.Add(DtpCikisTarihi);
            Controls.Add(DtpGirisTarihi);
            Controls.Add(MskTxtTelefon);
            Controls.Add(TxtKimlikNo);
            Controls.Add(TxtMail);
            Controls.Add(TxtSoyadi);
            Controls.Add(TxtAdi);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(BtnAra);
            Controls.Add(BtnSil);
            Controls.Add(BtnGuncelle);
            Controls.Add(BtnVerileriGoster);
            Controls.Add(listView1);
            Name = "FrmMusteriler";
            Text = "Müşteri Bilgileri";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListView listView1;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private ColumnHeader columnHeader6;
        private ColumnHeader columnHeader7;
        private ColumnHeader columnHeader8;
        private ColumnHeader columnHeader9;
        private ColumnHeader columnHeader10;
        private ColumnHeader columnHeader11;
        private Button BtnVerileriGoster;
        private Button BtnGuncelle;
        private Button BtnSil;
        private Button BtnAra;
        private ComboBox comboBox1;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private TextBox TxtUcret;
        private TextBox TxtOdaNo;
        private Label label8;
        private DateTimePicker DtpCikisTarihi;
        private DateTimePicker DtpGirisTarihi;
        private MaskedTextBox MskTxtTelefon;
        private TextBox TxtKimlikNo;
        private TextBox TxtMail;
        private TextBox TxtSoyadi;
        private TextBox TxtAdi;
        private Label label7;
        private Label label6;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox1;
        private Button BtnTemizle;
    }
}